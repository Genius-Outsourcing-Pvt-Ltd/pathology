===================Steps to Create database===================
1. Run the database.sql script file to your server by using user root. 
It will create pathology_kashif database and database user pathology.

===================Prepare Application===================
2. Extract source folder to your web root.
3. Link your url to the path source\public
4. change application database configuration in source\application\configs\application.ini
	change resources.db.params.host, resources.db.params.username, resources.db.params.password and 
	resources.db.params.dbname according to your database server.
5. Download Zend 1.12.13 
	from https://packages.zendframework.com/releases/ZendFramework-1.12.13/ZendFramework-1.12.13-minimal.zip
6. Copy ZendFramework-1.12.13-minimal\library\Zend to source\library
7. Download and place mpdf to source\library the folder should look like source\library\mpdf i.e; rename the folder
	you can download mpdf from: http://mpdf1.com/repos/MPDF60.zip but don't forget to rename it to mpdf
8. Download and place PHPMailer-master to source\library from following url:
	https://github.com/PHPMailer/PHPMailer
Folders are created in source\library which are required to replace with libraries
9. Default user is created with username admin and password admin
10. Patient's authentication is done by his mrn no and same as password.
11. If you are unable to setup the application, application is running at http://pathology.geniusoutsourcing.software/
===================Assumptions===================
1. A patient can be added to the system or can be searched from existing patients
	on the basis of patient name and M.R.N No.
2. Patient Test Orders can be made by selecting tests.
3. Patient Test Results can be entered later by selecting an order.
4. The Patient can login into the system by using his mrn no as username and mrn no as password.
5. User can view his Test orders.
6. User can view detail of his test orders.
7. User can download pdf of his test orders.
8. User can email pdf of his test orders.

===================Feedback===================
Requirement was too much generic. Requirement should be narrowed down.