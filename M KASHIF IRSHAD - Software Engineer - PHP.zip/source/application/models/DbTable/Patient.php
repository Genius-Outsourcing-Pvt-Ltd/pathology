<?php

class Application_Model_DbTable_Patient extends Zend_Db_Table_Abstract {

    protected $_name = 'patients';

}

