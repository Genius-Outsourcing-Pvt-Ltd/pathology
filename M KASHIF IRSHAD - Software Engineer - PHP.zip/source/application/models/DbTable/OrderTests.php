<?php

class Application_Model_DbTable_OrderTests extends Zend_Db_Table_Abstract {

    protected $_name = 'order_tests';

}

