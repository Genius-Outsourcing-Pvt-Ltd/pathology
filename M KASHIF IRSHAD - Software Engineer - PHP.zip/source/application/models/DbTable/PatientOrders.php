<?php

class Application_Model_DbTable_PatientOrders extends Zend_Db_Table_Abstract {

    protected $_name = 'patient_orders';

}

